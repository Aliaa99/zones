<?php
include 'header.php';
?>
 
<div class="contact-us py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-8">
                <div class="form-contact my-5 py-4  text-center animated bounceInRight">
                    <a href="#"> الرئيسية  / </a><span>أخبارنا </span>
                </div>
            </div>
        </div>
    </div>
</div>




<div class="news my-5 "  data-aos="flip-up"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="2000">
    <div class="container">
        <div class="row">
        
            <div class="col-md-6">
                <div class="news-left text-right py-2">
                    <div class="row">
                        <div class="col-xs-4">
                            <img src="images/1.png" alt="">
                        </div>
                        <div class="col-xs-8">
                            <h5 class="mb-3"> لا صحة فيما يخص تحديد اسعار الاستقدام </h5>
                            <p>لاصحه لمايتم تداوله مؤخراً بين مجموعات الواتساب فيمايخص تحديد أسعار #الأستقدام ولم تٌلزم المكاتب على تحديدها من ....  </p>
                            <a href="#"  class="more">المزيد</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="news-left text-right py-2">
                    <div class="row">
                        <div class="col-xs-4">
                            <img src="images/1.png" alt="">
                        </div>
                        <div class="col-xs-8">
                            <h5 class="mb-3"> لا صحة فيما يخص تحديد اسعار الاستقدام </h5>
                            <p>لاصحه لمايتم تداوله مؤخراً بين مجموعات الواتساب فيمايخص تحديد أسعار #الأستقدام ولم تٌلزم المكاتب على تحديدها من ....  </p>
                            <a href="#"  class="more">المزيد</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php
include 'footer.php';
?>
