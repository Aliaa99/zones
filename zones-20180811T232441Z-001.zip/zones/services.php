<?php
include 'header.php';
?>
 
<div class="contact-us py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-8">
                <div class="form-contact my-5 py-4  text-center animated bounceInRight">
                    <a href="#"> الرئيسية  / </a> <span>الخدمات</span>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="services mb-5 pb-5 mt-5" data-aos="zoom-in"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="2000">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="one-service p-4 hvr-float">
                    <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                    <img src="images/1.png" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
            <div class="one-service p-4 hvr-float">
                    <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                    <img src="images/1.png" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="one-service p-4 hvr-float">
                    <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                    <img src="images/1.png" alt="">
                </div>
            </div>
        </div>
    </div>

</div>

<?php
include 'send-order.php';
?>


<?php
include 'footer.php';
?>
