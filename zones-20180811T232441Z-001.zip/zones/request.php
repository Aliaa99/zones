<?php
include 'header.php';
?>
 
<div class="contact-us py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-8">
                <div class="form-contact my-5 py-4  text-center animated bounceInRight">
                    <a href="#"> الرئيسية  / </a><span>طلب الاستقدام</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="request text-right py-5 ">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-push-2">
                <h6>برجاء ملئ النموذج التالى :</h6>
                <form action="">
                    <div class="form-div">
                        <input type="text" placeholder="الأسم ">
                    </div>
                    <div class="form-div">
                        <input type="email" placeholder="الايميل ">
                    </div>
                    <div class="form-div">
                        <input type="number" placeholder="الهاتف ">
                    </div>
                    <div class="form-div">
                        <input type="text" placeholder="المحافظة ">
                    </div>
                    <div class="form-div">
                        <input type="text" placeholder="نوع الطلب ">
                    </div>
                    <div class="form-div text-center my-5">
                        <input type="submit" placeholder="ارسال الآن ">
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>


<?php
include 'footer.php';
?>
