<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>zones</title>
    <link rel="stylesheet" href="css/bootstrap4.css">
    <link rel="stylesheet" href="css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/hover-min.css">
    <link rel="stylesheet" href="css/lightbox.css">
    <link rel="stylesheet" href="css/stylesheet.css">
    <link rel="shortcut icon" href="images/logo.png">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <div class="zones-head">
        <div class="container">
            <div class="main-haeder pb-5 pt-3">
                <div class="row">
                    <div class="col-lg-7 col-md-12">
                        <div class="logo-img text-right ">
                            <a href="index.php"><img src="images/logo.png" alt="" class="logo"></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="addres text-right">
                            <p>المملكة العربية السعودية</p>
                            <span>الطائف</span>
                        </div>                      
                    </div>
                    <div class="col-lg-2 col-md-6">
                        <div class="telephone text-right">
                            <p>022858/958789</p>
                            <span>25577/88/9877</span>
                        </div>
                    </div>
                </div>
            </div>
 <!-- nav bar -->
            <div class="list animated zoomIn">
                <ul class="nav">
                    <li class="nav-item active">
                        <a class="nav-link  py-4 px-4" href="index.php">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4 about-header" href="about.php">عن الشركة</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4" href="#">مميزاتنا</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4 blog-header" href="services.php">الخدمات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4" href="request.php">طلب استقدام</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4 contact" href="news.php"> أخبارنا</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4 contact" href="contact-us.php"> تواصل معنا</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>



<!-- side menu-->
<div class="side-menu" >
    <div class="container">
       <div class="side-menu-header">
       <div class="adres-telephone">
            <div class="row">
                <div class="col-xs-6">
                    <div class="adress3">
                        <p>المملكة العربية السعودية </p>
                        <p>الطائف  </p>
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="tele3">
                        <p>3669889878899 </p>
                        <p>3669889878899 </p>
                    </div>
                </div>
            </div>
       </div>
          <a href="#side-list" class="open-menu">
             <i class="fas fa-align-justify"></i>
          </a>
          <a href="#" class="logo-img">
            <img src="images/logo.png">
          </a>
        </div>
        <div class="menu2 animated fadeInRight" id="side-list">
            <a href="#side-list" class="close-menu">
              <i class="fa fa-times" aria-hidden="true"></i>
            </a>
                <ul class="nav">
                    <li class="nav-item active">
                        <a class="nav-link  py-4 px-4" href="index.php">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4 about-header" href="about.php">عن الشركة</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4" href="#">مميزاتنا</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4 blog-header" href="services.php">الخدمات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4" href="request.php">طلب استقدام</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4 contact" href="news.php"> أخبارنا</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  py-4 px-4 contact" href="contact-us.php"> تواصل معنا</a>
                    </li>
                </ul>

        </div>
    </div>
</div>
</header>
