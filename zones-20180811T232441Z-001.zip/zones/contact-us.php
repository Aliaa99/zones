<?php
include 'header.php';
?>
 
<div class="contact-us py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-8">
                <div class="form-contact my-5 py-4  text-center animated bounceInRight">
                    <a href="#"> الرئيسية  / </a><span>تواصل معنا</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="contact text-right my-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-4  col-md-6">
                <h6>إرسال رسالة</h6>
                <form action="">
                    <div class="form-div">
                        <input type="text" placeholder="الأسم">
                        <input type="email" placeholder="الايميل">
                    </div>
                    <div class="form-div">
                        <textarea name="" id=""  rows="6" placeholder="الرسالة"></textarea>
                    </div>
                    <div class="form-div">
                        <input type="submit" class="hvr-float">
                    </div>
                </form>
            </div>
            <div class="col-lg-4 col-md-6 col-lg-push-1">
                <h6>معلومات التواصل </h6>
                <ul>
                    <li class="address"><a href="#">الطائف -الطائف-رسراس</a></li>
                    <li class="tele1"><a href="#">117996674899</a></li>
                    <li class="tele2"><a href="#">+50502145</a></li>
                    <li class="mail"><a href="#">aliaa@bb4it.com</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6">
                <h6>تابعنا </h6>
                <ul class="social">
                    <li><a href="#"><i class="fab fa-facebook-f"></i> فيس بوك </a></li>
                    <li><a href="#"> <i class="fab fa-twitter"></i> تويتر</a></li>
                    <li><a href="#"> <i class="fab fa-google-plus-g"></i> جوجل</a></li>
                    <li><a href="#"> <i class="fab fa-instagram"></i> انستجرام</a></li>
                </ul>
            </div>

        </div>
    </div>
</div>

<div class="map mb-5">
    <div class="container">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d55251.37709962692!2d31.293483736021493!3d30.059483810357758!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sar!2seg!4v1533479841731"  height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
</div>
<?php
include 'footer.php';
?>
