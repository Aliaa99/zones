<?php
include 'header.php';
?>
 
<div class="contact-us py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-8">
                <div class="form-contact my-5 py-4  text-center animated bounceInRight">
                    <a href="#"> الرئيسية  / </a> <a href="#"> أخبارنا  / </a><span>طلب تغيير عاصمة أندونسيا</span>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="service-details py-5 text-right mb-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <img src="images/1.png" alt="">
            </div>
            <div class="col-md-8">
            <div class="social-date">
                <span class="float-right"> 15 مارس 2018</span>
                <a href="#"class="float-left hvr-float"><i class="fab fa-facebook-f"></i></a>
                <a href="#"class="float-left hvr-float"><i class="fab fa-twitter"></i></a>
                <a href="#"class="float-left hvr-float"><i class="fab fa-google-plus-g"></i></a>
            </div>
            <div class="clear-fix">
            </div>
                <p>هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص. إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات أو عبارات محرجة أو غير لائقة مخبأة في هذا النص. بينما تعمل جميع مولّدات نصوص لوريم إيبسوم على الإنترنت على إعادة تكرار مقاطع من نص لوريم إيبسوم نفسه عدة مرات بما تتطلبه الحاجة، يقوم مولّدنا هذا باستخدام كلمات من قاموس يحوي </p>
                <p>هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص. إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات أو عبارات محرجة أو غير لائقة مخبأة في هذا النص. بينما تعمل جميع مولّدات نصوص لوريم إيبسوم على الإنترنت على إعادة تكرار مقاطع من نص لوريم إيبسوم نفسه عدة مرات بما تتطلبه الحاجة، يقوم مولّدنا هذا باستخدام كلمات من قاموس يحوي </p>
                <p>هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص. إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات أو عبارات محرجة أو غير لائقة مخبأة في هذا النص. بينما تعمل جميع مولّدات نصوص لوريم إيبسوم على الإنترنت على إعادة تكرار مقاطع من نص لوريم إيبسوم نفسه عدة مرات بما تتطلبه الحاجة، يقوم مولّدنا هذا باستخدام كلمات من قاموس يحوي </p>
            </div>
        </div>
    </div>
</div>



<div class="news mb-5"  data-aos="flip-up"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="2000">
    <div class="sub-title text-center">
        <h1 class="pb-5">المزيد من الأخبار</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="news-right text-right">
                    <div class="owl-carousel owl-theme">
                        <div class="item">
                        <a href="#">
                            <img src="images/1.png" alt="">
                            <h5 class="mt-4 mb-3"> لا صحة فيما يخص تحديد اسعار الاستقدام </h5>
                            <p>لاصحه لمايتم تداوله مؤخراً بين مجموعات الواتساب فيمايخص تحديد أسعار #الأستقدام ولم تٌلزم المكاتب على تحديدها من ....  </p>
                            <a href="#" class="more">المزيد</a>
                        </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="news-left text-right py-2">
                    <div class="row">
                        <div class="col-xs-4">
                            <img src="images/1.png" alt="">
                        </div>
                        <div class="col-xs-8">
                            <h5 class="mb-3"> لا صحة فيما يخص تحديد اسعار الاستقدام </h5>
                            <p>لاصحه لمايتم تداوله مؤخراً بين مجموعات الواتساب فيمايخص تحديد أسعار #الأستقدام ولم تٌلزم المكاتب على تحديدها من ....  </p>
                            <a href="#"  class="more">المزيد</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include 'footer.php';
?>
