<div class="countries text-center py-5 " data-aos="fade-up"
     data-aos-duration="3000">
    <div class="container">
        <h1 class="mt-4">نطاقات الاستقدام</h1>
        <h4 class="mt-4"> البلدان المتاحه :</h4>
        <p class="pb-4">الفلبين - فيتنام - بنجلاديش - اوغندا - نيجيريا - المغرب</p>
        <div class="mb-5">
            <a href="#" class="py-2 px-5 hvr-float"> ارسل الطلب الآن </a>
        </div>
    </div>
</div>
