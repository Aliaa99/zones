<?php
include 'header.php';
?>
 
<div class="contact-us py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-8">
                <div class="form-contact my-5 py-4  text-center animated bounceInRight">
                    <form action="" class="py-5 px-4">
                        <h4 class="mb-5">دعنا نتواصل معك</h4>
                        <div class="form-div mt-3 mb-4 ">
                            <input type="text" class="py-3 px-3" placeholder="الاسم">
                        </div>
                        <div class="form-div mt-3 mb-4 ">
                            <input type="email" class="py-3 px-3" placeholder="الايميل">
                        </div>
                        <div class="form-div mt-3 mb-4 ">
                            <input type="number" class="py-3 px-3" placeholder=" الهاتف">
                        </div>
                        <div class="form-div mt-3 mb-4 ">
                            <input type="submit" class="py-3 px-3 mt-4 mb-3 hvr-float" placeholder="ارسال الان">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include 'about-part.php';
?>

<div class="services mb-5 pb-5" data-aos="zoom-in"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="2000">
    <div class="sub-title text-center">
        <h1 class="pb-5">الخدمات</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <a href="single-service.php">
                    <div class="one-service p-4 hvr-float">
                        <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                        <img src="images/1.png" alt="">
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-md-6">
            <a href="single-service.php">
                    <div class="one-service p-4 hvr-float">
                        <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                        <img src="images/1.png" alt="">
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-md-6">
                <a href="single-service.php">
                    <div class="one-service p-4 hvr-float">
                        <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                        <img src="images/1.png" alt="">
                    </div>
                </a>
            </div>
        </div>
    </div>

</div>

<?php
include 'send-order.php';
?>

<div class="news mb-5"  data-aos="flip-up"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="2000">
    <div class="sub-title text-center">
        <h1 class="pb-5">أخبارنا</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="news-right text-right">
                    <div class="owl-carousel owl-theme">
                        <div class="item">
                        <a href="single-news.php">
                            <img src="images/1.png" alt="">
                            <h5 class="mt-4 mb-3"> لا صحة فيما يخص تحديد اسعار الاستقدام </h5>
                            <p>لاصحه لمايتم تداوله مؤخراً بين مجموعات الواتساب فيمايخص تحديد أسعار #الأستقدام ولم تٌلزم المكاتب على تحديدها من ....  </p>
                            <a href="#" class="more">المزيد</a>
                        </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="news-left text-right py-2">
                    <div class="row">
                        <div class="col-xs-4">
                            <img src="images/1.png" alt="">
                        </div>
                        <div class="col-xs-8">
                            <h5 class="mb-3"> لا صحة فيما يخص تحديد اسعار الاستقدام </h5>
                            <p>لاصحه لمايتم تداوله مؤخراً بين مجموعات الواتساب فيمايخص تحديد أسعار #الأستقدام ولم تٌلزم المكاتب على تحديدها من ....  </p>
                            <a href="single-news.php"  class="more">المزيد</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include 'footer.php';
?>
