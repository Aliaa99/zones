<?php
include 'header.php';
?>
 
<div class="contact-us py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-8">
                <div class="form-contact my-5 py-4  text-center animated bounceInRight">
                    <a href="#"> الرئيسية  / </a> <span>عن الشركة</span>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include 'about-part.php';
?>

<?php
include 'send-order.php';
?>

<?php
include 'footer.php';
?>
