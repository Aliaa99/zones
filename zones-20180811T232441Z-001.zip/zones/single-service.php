<?php
include 'header.php';
?>
 
<div class="contact-us py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-8">
                <div class="form-contact my-5 py-4  text-center animated bounceInRight">
                    <a href="#"> الرئيسية  / </a> <a href="#"> الخدمات  / </a> <span>عنوان الخبر</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="service-details py-5 text-right mb-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h4>عنوان الخبر</h4>
                <img src="images/1.png" alt="">
            </div>
            <div class="col-md-8">
                <p>هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص. إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات أو عبارات محرجة أو غير لائقة مخبأة في هذا النص. بينما تعمل جميع مولّدات نصوص لوريم إيبسوم على الإنترنت على إعادة تكرار مقاطع من نص لوريم إيبسوم نفسه عدة مرات بما تتطلبه الحاجة، يقوم مولّدنا هذا باستخدام كلمات من قاموس يحوي </p>
                <p>هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص. إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات أو عبارات محرجة أو غير لائقة مخبأة في هذا النص. بينما تعمل جميع مولّدات نصوص لوريم إيبسوم على الإنترنت على إعادة تكرار مقاطع من نص لوريم إيبسوم نفسه عدة مرات بما تتطلبه الحاجة، يقوم مولّدنا هذا باستخدام كلمات من قاموس يحوي </p>
                <p>هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص. إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات أو عبارات محرجة أو غير لائقة مخبأة في هذا النص. بينما تعمل جميع مولّدات نصوص لوريم إيبسوم على الإنترنت على إعادة تكرار مقاطع من نص لوريم إيبسوم نفسه عدة مرات بما تتطلبه الحاجة، يقوم مولّدنا هذا باستخدام كلمات من قاموس يحوي </p>
            </div>
        </div>
    </div>
</div>

<div class="services mb-5 pb-5" data-aos="zoom-in"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="2000">
    <div class="sub-title text-center">
        <h1 class="pb-5">خدمات اخرى</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="one-service p-4 hvr-float">
                    <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                    <img src="images/1.png" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
            <div class="one-service p-4 hvr-float">
                    <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                    <img src="images/1.png" alt="">
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="one-service p-4 hvr-float">
                    <h4 class="text-right mb-3">تأجير الخدمات العماليه لكبار العمال  </h4>
                    <img src="images/1.png" alt="">
                </div>
            </div>
        </div>
    </div>

</div>

<?php
include 'send-order.php';
?>


<?php
include 'footer.php';
?>
