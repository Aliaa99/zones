<footer>
  <div class="footer pt-4 "data-aos="fade-up"
     data-aos-duration="3000">
    <div class="footer-haed my-4">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-8">
            <img src="images/logo.png" alt="">
          </div>
          <div class="col-lg-6 col-md-4">
            <a href="#" class="hvr-float"><i class="fab fa-instagram"></i></a>
            <a href="#" class="hvr-float"><i class="fab fa-google-plus-g"></i></a>
            <a href="#" class="hvr-float"><i class="fab fa-twitter"></i></a>
            <a href="#" class="hvr-float"><i class="fab fa-facebook-f"></i></a>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6">
          <h4>تابعنا على تويتر </h4>
          <div class="tw">
                <a class="twitter-timeline" data-width="100%" data-height="100%" href="https://twitter.com/Jemy_poetry?ref_src=twsrc%5Etfw">Tweets by Jemy_poetry</a>
                <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
            </div>

        </div>
        <div class="col-lg-4 col-md-6">
          <h4>الاقسام الرئيسية</h4>
          <ul class="main-list-footer">
            <li><a href="#">الرئيسية</a></li>
            <li><a href="#">عن الشركة</a></li>
            <li><a href="#">الخدمات</a></li>
            <li><a href="#">ارسال طلب </a></li>
            <li><a href="#">اخبارنا</a></li>
            <li><a href="#">توصل معنا</a></li>
          </ul>
        </div>
        <div class="col-lg-4 col-md-6">
          <h4>تواصل معنا</h4>
          <ul>
            <li class="addres2"><a href="#">الطايف - شارع ابو بكر - مبنى سيتى </a></li>
            <li class="telephone2"><a href="#">050214687</a></li>
            <li class="telephone2"><a href="#">01114587155</a></li>
            <li class="mail2"><a href="#">aliaa@bb4it.com</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="by py-3">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 text-right">
            <p>جميع الحقوق محفوظة لنطاقات الأستخدام 2018</p>
          </div>
          <div class="col-sm-6 text-left">
            <p>تصميم وبرمجة <span><a href="#">براند</a></span> </p>
          </div>
        </div>
      </div>
    </div>
    <!-- button to top -->
      <div class="button-up" data-aos="flip-left"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="3000">
        <a href="" class="hvr-float"><i class="fas fa-long-arrow-alt-up"></i></a>
      </div>

  </div>

</footer>

<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap4.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/lightbox.js"></script>
<script src="js/aos.js"></script>
<script>
  AOS.init();
</script>
<script src="js/main.js"></script>
</body>
</html>